// dummy auth service for testing without backend
// swap these with real api calls when the backend is ready

export const register = async (userData) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ message: "Registration successful", user: userData })
    }, 500)
  })
}

export const login = async (credentials) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const dummyToken = "dummy-jwt-token-12345"
      const dummyUser = {
        id: 1,
        name: "Test User",
        email: credentials.email || "test@example.com"
      }
      localStorage.setItem("token", dummyToken)
      localStorage.setItem("user", JSON.stringify(dummyUser))
      resolve({ token: dummyToken, user: dummyUser })
    }, 500)
  })
}

export const logout = () => {
  localStorage.removeItem("token")
  localStorage.removeItem("user")
}

export const isAuthenticated = () => {
  return !!localStorage.getItem("token")
}
