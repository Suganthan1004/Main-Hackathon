import api from "./api"

export const getAllRestaurants = async () => {
  const response = await api.get("/restaurants")
  return response.data
}

export const getRestaurantMenu = async (restaurantId) => {
  const response = await api.get(`/restaurants/${restaurantId}/menu`)
  return response.data
}
